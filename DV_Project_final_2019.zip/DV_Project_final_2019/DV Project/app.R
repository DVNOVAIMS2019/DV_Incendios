library(leaflet)
library(shiny)
library(htmltools)
library(highcharter)
library(rgdal)
library(shinythemes)
library(sp)

require(shiny)
require(highcharter)

# Reads Portugal shapefiles
mymap <- readOGR('data/pt/pt_distritos_4326.shp', layer = 'pt_distritos_4326')

# Loads the csv file into a dataframe
df <- read.csv2('data/incendios2010-2015_tipo_causa_2.csv')

# Transforms "frequencia" and "acc_frequncia"in percentage
df$frequencia <- df$frequencia * 100
df$acc_frequencia <- df$acc_frequencia * 100

#########################################################################

ui <- shinyUI(fluidPage(
  
  # Selects chosen theme from bootswatch
  theme = shinytheme("superhero"),
  
  # Sets the color for the background
  tags$head(
  tags$style(HTML(".leaflet-container { background: #2b3e50; }")),
  
  # Title
  titlePanel(h3("Incêndios em Portugal de 2010 a 2015", 
                style = "text-align: center;color:white;font-weight: 700; line-height: 1.5;background-color: #DF691A;display: block; margin-left: auto; margin-right: auto;height:40px;"),""),
  
  tabsetPanel(
    
    # First tab with Portugal map
      tabPanel(strong("GEOGRAFIA DOS FOGOS"),
               sidebarLayout(
                 sidebarPanel(
                   
                   # Creates the drop down list with "Ano"
                   selectInput(inputId = 'yearInput',
                                          label= h4('Selecionar o Ano: '),
                                          choices = c('2010','2011','2012','2013','2014','2015')),
                   
                              br(),br(),'Portugal é dos países da Europa que mais sofre com os incêndios, principalmente no verão quando as temperaturas são mais elevadas. Apesar de um longo historial de incêndios em território nacional, Portugal continua ano após ano a ser consumido pelas chamas. Visualize a distribuição dos fogos pelos vários distritos e conheça quais são os mais afetados ao longo dos anos.',
                              br(),br(),br(),br(),br(),br(),
                   
                              tags$img(src = "fire.png", height = 100, width = 100, style="display: block; margin-left: auto; margin-right: auto;")),
                 
                 mainPanel(leafletOutput(outputId = "plot1", height = 800)))),
      
    # Second tab with Bar Chart and Pie Chart
      tabPanel(strong('CAUSAS'),
               sidebarLayout(
                 sidebarPanel(
                   
                   # Creates the drop down list with "Ano"
                   selectInput(inputId = 'ano_ID', label= h4('Selecionar o Ano: '),choices = c('2010','2011','2012','2013','2014','2015')),
                   br(),br(),
                   'Existem cinco tipos para classificar a causa de um incêndio:',
                   br(),
                   strong('natural, intencional, negligente, reacendimento e desconhecida.'),
                   br(),
                   'Conheça as causas dos incêndios de cada distrito ao passar com o ponteiro do rato sobre cada barra do gráfico.',
                   br(),
                   'Encontre também as causas dos incêndios agregadas por ano no Pie Chart. ',
                   br(),br(),
                   'Nota: apenas a partir de 2012 surge a causa “Reacendimento”. O Pie chart desconsidera a causa “Desconhecido”.',
                   br(),br()),
                 
                 # Represents the Bar Chart
                 mainPanel(highchartOutput('plot2'))),
               
               # Represents the Pie Chart
               tabPanel('Evolu',highchartOutput('plot3'))),
    
    # Third tab with Treemap
     tabPanel(strong('ÁREA ARDIDA'),
             sidebarLayout(
               sidebarPanel(
                 
                 # Creates the drop down list with "Ano" and Distrito
                 selectInput(inputId = 'ano_ID2', label= h4('Selecionar o Ano: '),choices = c('2010','2011','2012','2013','2014','2015')),
                 selectInput('distrito_ID', label= h4('Distrito: '), choices = c('Aveiro','Beja','Braga','Braganca','Castelo Branco','Coimbra','Evora','Faro','Guarda','Leiria','Lisboa','Portalegre','Porto','Santarem','Setubal','Viana do Castelo','Vila Real','Viseu')),
                 br(),
                 'As áreas ardidas são classificadas da seguinte forma: área de povoamento, área agrícola e área de mato. A classificação das áreas permite perceber se as áreas mais importantes para homem, como a área agrícola ou de povoamento são ou não as mais penalizadas pelos fogos, em relação à área de mato.',
                 br(),br(),br()),
               
               # Represents the Treemap
               mainPanel(highchartOutput('plot4')))),
    
    fluidRow(
      
      #Represent the App credits
      column(6,
         h5("Desenvolvido por:", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 10; line-height: 1.1;
            text-align: right;
            color: white;"),
         h6("Ana Margarida Gomes (M20180551)", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 10; line-height: 1.1;
            text-align: right;
            color: white;"),
         h6("Bruno André (M20180147)", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 10; line-height: 1.1;
            text-align: right;
            color: white;"),
         h6("Ricardo Gonçalves (M20180509)", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 10; line-height: 1.1;
            text-align: right;
            color: white;")),
      
      column(2,
         h5("NOVA IMS", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 50; line-height: 1.1;
            text-align: left;
            color: white;"),
         h6("Universidade Nova de Lisboa", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 50; line-height: 1.1;
            text-align: left;
            color: white;"),
         h6("Data Visualization", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 50; line-height: 1.1;
            text-align: left;
            color: white;"),
         h6("Ano letivo 2018 / 2019", 
            style = "font-family: 'Helvetica', cursive;
            font-weight: 50; line-height: 1.1;
            text-align: left;
            color: white;"))) 

))))

#########################################################################

server <- shinyServer(function(input, output) {
  
  # Selects the right column in shapefile according to the input in first tab drop-down list
  selectedYear <- reactive({switch (input$yearInput,'2010'=mymap$N2010,
                                    '2011'=mymap$N2011,
                                    '2012'=mymap$N2012,
                                    '2013'=mymap$N2013,
                                    '2014'=mymap$N2014,
                                    '2015'=mymap$N2015)})
  
  # Represents output for First tab (Portugal Map)
  output$plot1 <- renderLeaflet({

labels <- sprintf("<strong>%s</strong><br>
                  %g incendios",mymap$DISTRITO, selectedYear()) %>%
  
  lapply(htmltools::HTML);

leaflet(mymap) %>%
  
  # Set the position and Zoom of the map
  setView(lng = -8.150611,
          lat = 39.000000,
          zoom = 7) %>%
  
  # Defines Map aesthetics
  addPolygons(data = mymap,
              color = "#444444",
              weight = 1,
              smoothFactor = 0.5,
              opacity = 1,
              fillOpacity = 1,
              label = labels,
              fillColor = ~colorQuantile('YlOrRd',selectedYear())(selectedYear()),
              highlightOptions = highlightOptions(color="white", weight = 2, bringToFront = TRUE)) %>%
  
  # Defines Map Legend
  addLegend(pal = colorBin('YlOrRd', domain = selectedYear()),
                values = ~selectedYear(),
                title = 'No. Incendios',
                position = 'topleft')
})
  
  # Represents output for second tab
  
    # Bar Chart
  output$plot2 <- renderHighchart({
    
    # Configures the tooltip
    x <- c("Desconhecida", "Intencional", "Natural","Negligente","Reacendimento")
    
    y <- sprintf("{point.%s}: .2f",
                 c("Desconhecida","Intencional", "Natural","Negligente","Reacendimento"))
    
    # Creates the tooltip
    tltip.str <- "<strong><i>{point.distrito}</i></strong><br>
    <strong>Intencional</strong>: {point.Intencional}<br>
    <strong>Natural</strong>: {point.Natural}<br>
    <strong>Negligente</strong>: {point.Negligente}<br>
    <strong>Reacendimento</strong>: {point.Reacendimento}<br>
    <strong>Desconhecida</strong>: {point.Desconhecida}<br>
    <strong style=\"color:#F00;\">"
    
    # Filters the dataset according to the input on Second tab drop-down list
    df1 <- df[which(df$Ano==input$ano_ID),]
    
    # Calculates the maximum frequency
    max_freq <- max(df1$frequencia)
    
    # Creates Bar chart
    highchart() %>%
      
      hc_add_series(df1, "column",
                    hcaes(y = frequencia),
                    name = ' ',
                    color= "#f0ad4e") %>%
      hc_title(text='<strong style=\"color:#fff;\">Quais as causas dos incêndios e como se distribuem pelos distritos ao longo dos anos?</strong><br>')%>%
      hc_yAxis(title = list(text = '<strong style=\"color:#fff;\">Percentagem do total de incêndios em Portugal</strong>'),
               labels = list(format = '<strong style=\"color:#fff;\">{value}%</strong>'),
               max = max_freq) %>%
      
      hc_xAxis(categories = df1$distrito) %>%
      
      hc_tooltip(useHTML = TRUE, headerFormat = '', pointFormat = tltip.str)
  })
  
  
    # Pie chart
  output$plot3 <- renderHighchart({
    
    # Aggregates all the data
    tudo.dist <- apply(df[which(df$Ano==input$ano_ID), c("Intencional","Natural","Negligente","Reacendimento")],
                       2, 
                       function(r)sum(r, na.rm=TRUE))
    
    tmp.df <- data.frame(type=c("Intencional","Natural","Negligente","Reacendimento"),
                         count=as.vector(tudo.dist))
    
    # Creates Pies chart
    highchart() %>%
      
      hc_title(text="<strong style=\"color:#fff;\">Principais causas apuradas:</strong><br>") %>%
      hc_chart(type="pie") %>%
      hc_add_series_labels_values(labels=tmp.df$type, 
                                  value=tmp.df$count,
                                  name="Total",
                                  center = c('65%', '40%'),
                                  showInLegend=FALSE)
    
    })
  
  # Represents output for third tab (Treemap)
  
  # Preprocesses our dataset to fit the treemap
  
  treemap.data <- reactive({
    ix <- which(df$distrito == input$distrito_ID & df$Ano == input$ano_ID2)
    
    tmp <- t(df[ix, c("area_povoamento", "area_mato", "area_agricola")])
    
    distrito.area_ardida <- as.vector(tmp)
    
    tmp.df <- data.frame("distrito"=c("Area povoamento", "Area mato", "Area agricola"), "area_ardida" = distrito.area_ardida*100, PN = c(10,20,30) )
    })
  
  
  output$plot4 <- renderHighchart({
    
    # Creates the tooltip
    tlp.str <- "<i>{point.area_ardida: %.1f}</i>"
    
    # Creates Treemp Chart
    treemap.data() %>%
      
      hchart("treemap", hcaes(x=distrito, value=area_ardida,color=PN)) %>%
      
      hc_title(text="<strong style=\"color:#fff;\">Qual a dimensão de área ardida por tipo de terreno em cada distrito ao longo dos anos?</strong>", style=list(fontsize="16px")) %>%
      
      hc_tooltip(pointFormat=tlp.str) %>%
      
      hc_colorAxis(stops = color_stops(n = 3, colors = c("#5bc0de", "#5cb85c", "#f0ad4e")))
  })
})

#########################################################################

shinyApp(ui, server)





